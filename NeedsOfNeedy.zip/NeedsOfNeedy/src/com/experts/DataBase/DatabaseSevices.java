package com.experts.DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseSevices {

	public Connection getConnection(){
		Connection con = null;
		// load mysql driver
		try{
			Class.forName("com.mysql.jdbc.Driver");
	
			// get connection from drivermanager using loaded driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/needofneedy", "root", "shashi7567@#$");
			return con;
		}catch(ClassNotFoundException | SQLException e){
			e.printStackTrace();
			return con;
		}
	}
	
}
