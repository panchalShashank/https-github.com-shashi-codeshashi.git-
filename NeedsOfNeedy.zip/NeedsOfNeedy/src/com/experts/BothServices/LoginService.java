package com.experts.BothServices;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.experts.DataBase.DatabaseSevices;

public class LoginService {
	
	DatabaseSevices dbcon;
	  
	public LoginService() 
	{
		dbcon = new DatabaseSevices();
	}

public boolean isValid(String uname,String uphone,String upass) throws NullPointerException, ClassNotFoundException, SQLException {
		
		Connection con = dbcon.getConnection();
		Statement st = con.createStatement();
		
		String query = "select * from register where EMAIL='"+ uname +"' OR PHONE ='"+uphone+"'";
		ResultSet rs = st.executeQuery(query);
		
		String dbpass = " ";
		//String dbuser = " ";
		while(rs.next()){
			//dbuser = rs.getString(2);
			dbpass = rs.getString(5);
		}
		con.close();
		if(dbpass.equals(upass)){
			return true;
		}
		
		else{
		return false;		
		}
	}
	
}
