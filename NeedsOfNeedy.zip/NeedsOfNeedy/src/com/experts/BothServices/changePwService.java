package com.experts.BothServices;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.experts.DataBase.DatabaseSevices;

public class changePwService {
	
	DatabaseSevices dbcon;
	  
	public changePwService() 
	{
		dbcon = new DatabaseSevices();
	}
	

	public boolean forChangePw(String Email, String Phone, String OldPw, String NewPw, String ConfirmPw) throws NullPointerException, ClassNotFoundException, SQLException {
		
		Connection con = dbcon.getConnection();
		Statement st = con.createStatement();
		
		String query = "select * from register where EMAIL='"+ Email +"' OR PHONE ='"+Phone+"'";
		ResultSet rs = st.executeQuery(query);
		
		String dbpass = " ";
		while(rs.next()){
			dbpass = rs.getString(5);
		}
		
		if(dbpass.equals(OldPw))
		{
			if(NewPw.equals(ConfirmPw))
			{			
				String query1 = "update register set PASSWORD = '"+NewPw+"' ,CONFIRM = '"+ConfirmPw+"' where EMAIL='"+ Email +"' OR PHONE ='"+Phone+"'";
				st.executeUpdate(query1);
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;		
		}
	}
}
