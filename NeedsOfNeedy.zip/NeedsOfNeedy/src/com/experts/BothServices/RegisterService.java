package com.experts.BothServices;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.xml.ws.Response;

import com.experts.DataBase.DatabaseSevices;

import jdk.nashorn.internal.ir.RuntimeNode.Request;



public class RegisterService {


	DatabaseSevices dbcon;
	  
	public RegisterService() 
	{
		dbcon = new DatabaseSevices();
	}
	
	public int isDone(String fname, String lname,String mobile, String password, String confirm, String email) throws SQLException{
		
		
		Connection con = dbcon.getConnection();
		Statement st = con.createStatement();
		
		String query ="select * from register";
		ResultSet rs = st.executeQuery(query);
		int lastcount = rs.last() ? rs.getRow() : 0;
		//int ncount = count+1;
		
		String query3 = "select EMAIL,PHONE from register where EMAIL='"+email+"' PHONE='"+mobile+"'";
		ResultSet rs3 = st.executeQuery(query3);
		//int lastcount = rs3.last() ? rs3.getRow() : 0;
		String mail="";
		String phone = "";
		while(rs3.next()){
			phone = rs3.getString(1);
			mail = rs3.getString(2);
		}
//		
		//if(!(rs3.getString("EMAIL")).equals(email) && !(rs3.getString("PHONE")).equals(mobile))
		if(!mail.equals("email") && !phone.equals("mobile"))
		{			
			if(password.equals(confirm))
			{
			String query1 = "insert into register(FIRSTNAME,LASTNAME,PHONE,PASSWORD,CONFIRM,EMAIL) values('"+fname+"','"+lname+"','"+mobile+"','"+password+"','"+confirm+"','"+email+"')";
			st.executeUpdate(query1);
			}
			else
			{
				//request.getRequestDispatcher("solicitudWizard.jsp").forward(request, response);
	           
				System.out.println("data can not fill in database");
				
			}
		}
		String query2 ="select * from register";
		ResultSet rs2 = st.executeQuery(query2);
		
		int count = rs2.last() ? rs2.getRow() : 0;
		
		if(count > lastcount)
		{
			return 1;
		}
		else
		{
			return	2;
		}
	 	
	}	
	
	
}
