package com.experts.RegLogin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.experts.BothServices.RegisterService;

//import com.first.services.Dbregister;


@WebServlet("/DataRegister")
public class DataRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DataRegister() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pr = response.getWriter();
		pr.println("Hello Java");
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw =response.getWriter();
		String fname = request.getParameter("firstName");
		String lname = request.getParameter("lastName");
		String mobile = request.getParameter("phone");
		String password = request.getParameter("passWord");
		String confirm = request.getParameter("conFirm");
		String email = request.getParameter("eMail");

			RegisterService reg = new RegisterService();
		try {
			int save = reg.isDone(fname,lname,mobile,password,confirm,email);
			
			if(save == 1){
				pw.println("1 row inserted in Database");
				RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
				rd.forward(request, response);
				
			}
			else{
				pw.println("<html><body><h1>You Got a error</h1></body></html>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
