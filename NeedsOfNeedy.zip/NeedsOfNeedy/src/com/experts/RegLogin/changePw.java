package com.experts.RegLogin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.experts.BothServices.LoginService;
import com.experts.BothServices.changePwService;


@WebServlet("/changePw")
public class changePw extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String Email = request.getParameter("IdName");
		String Phone = request.getParameter("IdName");
		String OldPw = request.getParameter("oldPw");
		String NewPw = request.getParameter("newPw");	
		String ConfirmPw = request.getParameter("confirmPw");
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		changePwService isChange = new changePwService();
		
		try {
			boolean PwChange = isChange.forChangePw(Email, Phone, OldPw, NewPw, ConfirmPw);
			
			if(PwChange){
				
				//pw.println("<html><body><h1>Welcome"+" "+ Fname +" "+ Lname +"</h1></body></html>");
				//pw.println("<html><body><a href='login.html'><input type='submit' value='logout'/></a></body></html>");
				
				RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
				rd.forward(request, response);
			}
			
			else {
				pw.println("<html><body>Entered Password in invalid</body></html>");
				//response.sendRedirect("login.jsp");			
				}
			
		} catch (SQLException | ClassNotFoundException | NullPointerException e) {
			// TODO Auto-generated catch block
			pw.println("'"+ e + "'");
		}
	}

}
