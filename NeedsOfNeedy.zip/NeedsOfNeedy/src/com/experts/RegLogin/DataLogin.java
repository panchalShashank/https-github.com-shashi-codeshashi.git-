package com.experts.RegLogin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.experts.BothServices.LoginService;


@WebServlet("/DataLogin")
public class DataLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public DataLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String uname = request.getParameter("eMail");
		String uphone = request.getParameter("eMail");
		String upass = request.getParameter("passWord");
		
		//String Fname = request.getParameter("firstName");
		//String Lname = request.getParameter("lastName");
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		LoginService valid = new LoginService();
		
		try {
			boolean userValid = valid.isValid(uname,uphone, upass);
			
			if(userValid){
				
				//pw.println("<html><body><h1>Welcome"+" "+ Fname +" "+ Lname +"</h1></body></html>");
				//pw.println("<html><body><a href='login.html'><input type='submit' value='logout'/></a></body></html>");
				
				RequestDispatcher rd = request.getRequestDispatcher("index-4.jsp");
				rd.forward(request, response);
			}
			
			else {
				pw.println("Please, Login again");
				response.sendRedirect("login.jsp");			}
			
		} catch (SQLException | ClassNotFoundException | NullPointerException e) {
			// TODO Auto-generated catch block
			pw.println("'"+ e + "'");
		}
		
	}

}
